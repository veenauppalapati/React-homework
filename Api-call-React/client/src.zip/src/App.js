import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Results from './Components/API-response'
class App extends Component {
  render() {
    return (
      <div>
        <Results />
      </div>
    );
  }
}

export default App;
