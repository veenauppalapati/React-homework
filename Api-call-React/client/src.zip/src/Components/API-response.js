import React, {Component} from 'react';
import API from '../utils/API';

class Results extends Component {
    state = {
        results: [],
    
    }
    // what if i just want to see the results
// componentDidMount(){
//     this.retrieveArticles();
// }

retrieveArticles = () => {
    API.search().then( res => {
        console.log(res.data.response.docs)
         this.setState({ results: res.data.response.docs }) 
    })
        
    .catch(err => console.log(err));
}

render() {

    return( 
        <div>
            <ul>
           {this.state.results.map((articles, index) => 
          <li key = {index}>  
        <h1>{articles.headline.main}</h1>
       
        <img src = {"https://static01.nyt.com/" + articles.multimedia[1].url}/><br/>
        
         <a
          href = {articles.web_url}>
           Click here to read the article
          </a>
          
          <span>{articles.snippet} </span>
          </li>   
           )} 
           </ul>
           <button onClick={this.retrieveArticles}>Submit</button>
        </div>
    )
}

}

export default Results;